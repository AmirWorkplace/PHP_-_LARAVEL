<?php

$views = 'home';
include("template.php");
?>
