<!-- http://localhost/PHP_Project/MultiPHP/profile.php -->
<?php

$views = 'profile';
include("template.php");

if (!isset($userid)) {
  header("location:login.php");
}

?> 