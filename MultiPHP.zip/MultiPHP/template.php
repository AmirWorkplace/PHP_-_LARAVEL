<!-- http://localhost/PHP_Project/MultiPHP/template.php -->

<?php

session_start();

include( "config/db/config.php");
include("config/user_controller/post.php");
include("config/user_controller/auth.php");

$authObj = new Auth();
$postObj = new Post();

if (isset($_SESSION['id'])) {
  $userid = $_SESSION['id'];
  $Uname = $_SESSION['username'];
}

if (isset($_GET['action'])) {
  if($_GET['action'] == 'logout'){
    $authObj->logOut();
  }
}

?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>E-Shop X E-Social</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
</head>

<body>


  <nav class="navbar shadow-sm navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand" href="index.php">E-Social</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav ms-auto">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          <a class="nav-link" href="add-post.php">Add Post</a>

          <?php if (isset($userid)) { ?>

            <a class="nav-link" href="profile.php">Profile</a>
            <a class="nav-link" href="?action=logout">Log Out</a>

          <?php } else { ?>

            <a class="nav-link" href="./register.php">Register</a>
            <a class="nav-link" href="./login.php">Log In</a>

          <?php } ?>

        </div>
      </div>
    </div>
  </nav>

  <section class="main-section my-5">
    <?php

      if ($views) {

        if ($views == 'home') {
          include("views/home_view.php");
        } elseif ($views == 'profile') {
          include("views/profile_view.php");
        } elseif ($views == 'add_post') {
        include("views/addpost_view.php");
        }

      } 
    ?>
  </section>








  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>

</html>