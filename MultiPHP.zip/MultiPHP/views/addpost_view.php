<?php
if (isset($_POST['post_submit'])) {
  $postObj->addPost($_POST, $conn);
}


?>








<div class="container">

  <?php if (isset($userid)) { ?>
    <div class="row">
      <div class="col-lg-8">
        <div class="form shadow p-3 m-3">
          <form action="" method="POST">
            <div class="form-grop mt-3">
              <label for="text" class="form-grup label">Post Title:</label>
              <input type="text" name="post_title" class="form-control mt-1">
            </div>
            <div class="form-grop mt-3">
              <label for="text" class="form-grup label">Post Content:</label>
              <textarea name="post_content" id="postDes" cols="30" rows="10" class="form-control"></textarea>
            </div>
            <!-- <div class="form-grop mt-3">
            <label for="post" class="form-grup label">Post Title:</label>
            <input type="text" name="post_title" class="form-control mt-1">
          </div> -->
            <div class="form-grop mt-3">
              <input type="submit" name="post_submit" value="GO!" class="form-control mt-1 btn btn-primary">
            </div>

          </form>
        </div>
      </div>
    </div>
  <?php } else { ?>

    <div class="container">
      <div class="container">
        <h1>Please Log in to create an Account!</h1>
      </div>
    </div>

  <?php } ?>

</div>