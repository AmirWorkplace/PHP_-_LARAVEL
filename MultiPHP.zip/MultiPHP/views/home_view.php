<?php

$postMsg = $postObj->displayPost($conn);

if (isset($_POST['like_count'])) {
  $postObj->addLike($_POST, $conn);
}

?>




<div class="container">
  <h1>Home Page:::::::::::::::::::::::::::::::::::::</h1>
</div><br><br>

<div class="container">
  <div class="col-sm-8">

    <?php while ($post = mysqli_fetch_assoc($postMsg)) { ?>

      <div class="post-container shadow my-3 p-4">
        <h2><?php echo $post['post_title']; ?></h2>
        <h6><?php echo $post['post_user_name']; ?> | <?php echo $post['post_date']; ?></h6>
        <p class="py-4"><?php echo $post['post_content']; ?></p>

        <?php if (isset($userid)) { ?>

          <div class="post-footer my-3">
            <form action="" method="POST">
              <input type="hidden" name="post_id" value="<?php echo $post['post_id']; ?>">
              <button type="submit" name="like_count" class="btn btn-sm btn-primary"><?php echo $post['post_like_count']; ?> Like</button>
            </form>
          </div>

        <?php } else { ?>

          <div class="post-footer my-3">
            <p class="btn btn-sm"><?php echo $post['post_like_count']; ?> Like</p>
          </div>

        <?php } ?>

      </div>

    <?php } ?>

  </div>
  <div class="col-sm-4"></div>
  <br>
</div>