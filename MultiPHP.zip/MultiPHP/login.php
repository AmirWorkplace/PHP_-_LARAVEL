<!-- Live Server link: http://localhost/PHP_Project/MultiPHP/login.php -->
<!-- Live Server link: http://localhost/PHP_Project/MultiPHP/register.php -->
<!-- Live Server link: http://localhost/PHP_Project/MultiPHP/profile.php -->

<?php

  session_start();

  if (isset($_SESSION['id'])) {
    header("location:profile.php");
  }

  include("config/db/config.php");
  include("config/user_controller/auth.php");

  $authObj = new Auth();

  if (isset($_POST['logBtn'])) {
    $msg = $authObj->signIn($_POST, $conn);
  }


?>




<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign In Accounts</title>

  <link rel="stylesheet" href="assets/user/CSS/bootstrap.min.css">
  <link rel="stylesheet" href="assets/user/CSS/register.css">
  <link rel="stylesheet" href="ColourfulRain/CSS/style.css">
  <link rel="stylesheet" href="Regiter_all_file/fontawesomeCSS/css/all.min.css">


</head>

<body>

  <!-- Rain Section Started -->
  <section>
    <script>
      function rain() {
        let amount = 200;
        let body = document.querySelector('section');
        let i = 0;
        while (i < amount) {
          let drop = document.createElement('i');

          let size = Math.random() * 5;
          let posX = Math.floor(Math.random() * window.innerWidth);
          let delay = Math.random() * -20;
          let duration = Math.random() * 5;

          drop.style.width = 0.2 + size + 'px';
          drop.style.left = posX + 'px';
          drop.style.animationDelay = delay + 's';
          drop.style.animationDuration = 1 + duration + 's';
          body.appendChild(drop);

          i++;
        }
      }

      rain();
    </script>
  </section>
  <!-- Rain Section Closed -->


  <div class="signup">
    <div class="cont">
      <div class="containerr">

        <!-- Return Messege -->
        <p class="form-control btn btn-danger">
          <?php if (isset($msg)) {
            echo $msg;
          } ?>
        </p>


        <div id="sign-in-section" class="shadow p-5 form-sec">
          <form action="" method="POST">
            <div class="title">
              <p>Sign In</p>

            </div>

            <div class="mb-3">
              <label for="email" class="form-label">Enter Your E-mail:</label>
              <input autocomplete="off" type="email" name="email" id="email" class="form-control" required>
            </div>

            <div class="mb-3">
              <label for="password" class="form-label">Enter Your Password:</label>
              <input type="password" name="password" id="password" class="form-control" required>
            </div>


            <div class="chek-mark">
              <span class="switchh switch"></span>
              <span class="switchBtn"></span>
              <span class="show-pass">Show Password!</span>
            </div>

            <input type="hidden" value="user" name="role">
            <input type="submit" value="GO!" class="btn form-control btn-primary" id="logBtn" name="logBtn">

          </form><br>
        </div>
      </div>
    </div>
  </div>





  <script src="assets/user/JavaScript/register.js"></script>
</body>

</html>