<!-- http://localhost/PHP_Project/MultiPHP/ -->

<?php

$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'multiphpprojects';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname,);


if ($conn) {
  echo "";
  // echo "Database Connected";
} else {
  echo "Database Not Connected";
}



?>