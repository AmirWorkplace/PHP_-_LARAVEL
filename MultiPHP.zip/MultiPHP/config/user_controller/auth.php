<?php


  class Auth{
    public function signup($data, $conn){

      $username = $data['userName'];
      $email = $data['email'];
      $password = $data['password'];
      $role = $data['role'];

      $checkUsername = "SELECT * FROM `user` WHERE `username` = '$username'";

      if(mysqli_num_rows(mysqli_query($conn, $checkUsername)) != 0){
        $msg = "This Username are already taken!";
        return $msg;
      }else{
        $checkEmail = "SELECT * FROM `user` WHERE `email` = '$email'";

        if(mysqli_num_rows(mysqli_query($conn, $checkEmail)) != 0){
          $msg = "This E-mail are already taken!";
          return $msg;
        }else{

          $query = "INSERT INTO `user`(`username`, `email`, `password`, `role`) VALUES ('$username','$email','$password','$role')";

          if(mysqli_query($conn, $query)){
            /* $msg = "Your Accounted Created SucccessFully!";
            return $msg; */
            header("location:login.php");
            
          }else{
            $msg = "Something Went Wrong ...?";
            return $msg;
          }
        }
      }
    }

    public function signIn($data, $conn){
      $email = $data['email'];
      $password = $data['password'];
      
      $query = "SELECT * FROM `user` WHERE `email` = '$email' AND `password` = '$password'";

      if(mysqli_query($conn, $query)){
        $results = mysqli_query($conn, $query);
        $userInfo = mysqli_fetch_assoc($results);

        if($userInfo){
          header("location:profile.php");

          session_start();

          $_SESSION['id'] =  $userInfo['id'];
          $_SESSION['username'] =  $userInfo['username'];
          $_SESSION['email'] =  $userInfo['email'];
          $_SESSION['password'] =  $userInfo['password'];
          $_SESSION['role'] =  'role';
        }else {
          $msg = "Your E-mail is Incorrect!";
          return $msg;
        }
      }
    }

    public function logOut(){
      session_unset();
      header("location:index.php");
    }


  }
