<?php

  class Post{

    public function addPost($data, $conn){

      $post_title = $data['post_title'];
      $post_content = $data['post_content'];
      $post_user_id = $_SESSION['id'];
      $post_user_name = $_SESSION['username'];
      $post_like_count = 0;
      $post_url = '';
      $post_date = date('d-m-Y h-m-s');

      $query = "INSERT INTO `userpost`(`post_title`, `post_content`, `post_user_id`, `post_user_name`, `post_like_count`, `post_url`, `post_date`) VALUES ('$post_title','$post_content',$post_user_id,'$post_user_name',$post_like_count,'$post_url','$post_date')";

      if(mysqli_query($conn, $query)){
        header('location:index.php');
      }
    }

    public function displayPost($conn){
      $query = "SELECT * FROM `userpost`";

      if(mysqli_query($conn, $query)){
        $results = mysqli_query($conn, $query);
        if(mysqli_num_rows($results) > 0){
          return $results;
        }else{
          return "Nothing here!";
        }
      }
    }

    public function addLike($data, $conn){
      $post_id = $data['post_id'];
      $like_userid = $_SESSION['id'];
      $like_username = $_SESSION['username'];

      $checkLike = "SELECT * FROM `like_history` WHERE `post_id`=$post_id AND `like_user_id`=$like_userid";
      
      if(mysqli_num_rows(mysqli_query($conn, $checkLike)) == 0){

        $addLikeQuery = "UPDATE `userpost` SET `post_like_count`=post_like_count+1 WHERE `post_id`=$post_id";

        mysqli_query($conn, $addLikeQuery);

        $query = "INSERT INTO `like_history`(`like_user_id`, `like_username`, `post_id`) VALUES ($like_userid,'$like_username','$post_id')";

        if (mysqli_query($conn, $query)) {
          header("location:index.php");
        }

      }

    }


  }


?>