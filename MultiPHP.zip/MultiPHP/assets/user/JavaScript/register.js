let submitLabel = document.getElementById("submit_label");
let regBtn = document.getElementById("regBtn");
let conMsg = document.getElementById("conMsg");
let password = document.getElementById("password");
let confirmPassword = document.getElementById("confirmPassword");

/* 
  let passwordValue = password.value;
  let conPassValue = confirmPassword.value;
*/

let Switchh = document.querySelector(".switch");
let switchBtn = document.querySelector(".switchBtn");
let showPass = document.querySelector(".show-pass");

switchBtn.addEventListener("click", () => {
  switchBtn.classList.add("switchLeft");
  Switchh.classList.add("switchActive");
  showPass.innerHTML = "Hide Password!";

  if (password.type === "password" || confirmPassword.type === "password") {
    password.type = "text";
    confirmPassword.type = "text";
  }
});

Switchh.addEventListener("click", () => {
  switchBtn.classList.remove("switchLeft");
  Switchh.classList.remove("switchActive");
  showPass.innerHTML = "Show Password!";

  if (password.type === "text" || confirmPassword.type === "text") {
    password.type = "password";
    confirmPassword.type = "password";
  }
});

confirmPassword.addEventListener("keyup", () => {
  let main_pass = password.value;
  let confirmPass = confirmPassword.value;

  //console.log(main_pass,confirmPass)

  if (main_pass == confirmPass) {
    conMsg.innerHTML = "";
    regBtn.style.display = "block";
    submitLabel.style.display = "none";
  } else {
    conMsg.innerHTML = "Password not Matched!";
    regBtn.style.display = "none";
    submitLabel.style.display = "block";
  }
});


password.addEventListener("keyup", () => {
  let main_pass = password.value;
  let confirmPass = confirmPassword.value;

  //console.log(main_pass,confirmPass)

  if (confirmPass == main_pass) {
    conMsg.innerHTML = "";
    regBtn.style.display = "block";
    submitLabel.style.display = "none";
  } else {
    conMsg.innerHTML = "Password not Matched!";
    regBtn.style.display = "none";
    submitLabel.style.display = "block";
  }
});
