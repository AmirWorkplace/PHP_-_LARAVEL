<?php

$views = 'add_post';
include("template.php");
?>

